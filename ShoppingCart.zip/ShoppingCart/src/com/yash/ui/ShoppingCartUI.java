package com.yash.ui;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.yash.entity.Category;
import com.yash.entity.Item;
import com.yash.entity.Product;
import com.yash.entity.SubCategory;
import com.yash.repository.ShoppingCartRepository;

public class ShoppingCartUI {

	public static void main(String[] args) {

		List<Category> categoryList=ShoppingCartRepository.getCategory();
		System.out.println("*********************Shopping application****************");
		try(Scanner scanner=new Scanner(System.in)){
		
			int count=1;
			for(Category category:categoryList) {
				System.out.println(count+"."+category.getCategoryDescription());
				count++;
			}
			
			System.out.println("Please select above category");
			System.out.print("Option:");
			int option=scanner.nextInt();
			Category selectedCategory=categoryList.get(option-1);
			count=1;
			for(SubCategory subCategory:selectedCategory.getCategories()) {
				System.out.println(count+"."+subCategory.getSubCategoryDescription());
				count++;
			}
			System.out.println("Please select above sub category");
			System.out.print("Option:");
			option=scanner.nextInt();
			SubCategory subCategory=selectedCategory.getCategories().get(option-1);
			count=1;
			for(Product product:subCategory.getProducts()) {
				System.out.println(count+"."+product.getProductDescription());
				count++;
			}
			System.out.println("Please select above Product");
			System.out.print("Option:");
			option=scanner.nextInt();
			Product product=subCategory.getProducts().get(option-1);
			count=1;
			for(Item item:product.getItems()) {
				System.out.println(count+"."+item.getItemDescription()+"\t"+item.getItemPrice());
				count++;
			}
					


			
		}catch(InputMismatchException e) {
			System.err.println("Error processing request please try again later");
		}
	}

}
